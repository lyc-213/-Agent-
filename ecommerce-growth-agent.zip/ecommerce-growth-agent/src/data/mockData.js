// ─── 顶部核心指标 ───────────────────────────────────────────────
export const METRICS = [
  { id: 'gmv',        label: '今日 GMV',   value: '¥84,320', delta: '-12.4%', trend: 'down', sub: 'vs 昨日' },
  { id: 'visitors',   label: '访客数',     value: '6,812',   delta: '-8.1%',  trend: 'down', sub: 'vs 昨日' },
  { id: 'conversion', label: '转化率',     value: '2.34%',   delta: '-0.6pp', trend: 'down', sub: '⚠ 异常' },
  { id: 'refund',     label: '退款率',     value: '4.78%',   delta: '+1.2pp', trend: 'up',   sub: '⚠ 预警' },
]

// ─── GMV 逐时数据（0–15点，每小时）────────────────────────────────
export const GMV_HOURLY = [
  { hour: '00', value: 1200 },
  { hour: '01', value:  890 },
  { hour: '02', value:  640 },
  { hour: '03', value:  420 },
  { hour: '04', value:  380 },
  { hour: '05', value:  720 },
  { hour: '06', value: 2100 },
  { hour: '07', value: 4300 },
  { hour: '08', value: 7200 },
  { hour: '09', value: 9100 },
  { hour: '10', value: 11400 },
  { hour: '11', value: 8300,  anomaly: true },
  { hour: '12', value: 6100,  anomaly: true },
  { hour: '13', value: 7800 },
  { hour: '14', value: 9200 },
  { hour: '15', value: 10600 },
]

// ─── 流量来源饼图 ─────────────────────────────────────────────────
export const TRAFFIC_SOURCE = [
  { name: '抖音投流',   value: 38, color: '#60a5fa' },
  { name: '搜索自然流', value: 24, color: '#4ade80' },
  { name: '店铺收藏',   value: 18, color: '#fbbf24' },
  { name: '直播间',     value: 12, color: '#a78bfa' },
  { name: '其他',       value: 8,  color: '#6b7280' },
]

// ─── 五大 Agent 定义 ─────────────────────────────────────────────
export const AGENTS = [
  {
    id: 'collector',
    name: '数据采集 Agent',
    icon: 'Database',
    color: 'blue',
    status: 'running',
    statusLabel: '运行中',
    summary: '已同步 5 路数据源，结构化处理完成',
    tokenCost: 840000,
    chainTitle: '数据采集 Agent — 处理流程',
    chain: [
      { step: 1, text: '连接淘宝交易 API / 抖音投流 API / 客服系统 Webhook，建立实时数据管道' },
      { step: 2, text: '清洗空值字段，统一时区为 UTC+8，标准化输出 Schema（交易 / 流量 / 退款 / 客服 / 内容）' },
      { step: 3, text: '将结构化数据写入消息队列，推送至异常诊断 Agent 消费，延迟 <2s' },
      { step: 4, text: '增量更新策略：30秒刷新一次，今日已处理记录 >214 万条，无丢失告警' },
    ],
  },
  {
    id: 'diagnose',
    name: '异常诊断 Agent',
    icon: 'ScanSearch',
    color: 'red',
    status: 'alert',
    statusLabel: '发现 3 项异常',
    summary: '长链推理：转化率下滑根因 → 爆款 SKU 详情页跳失 +23%',
    tokenCost: 1260000,
    chainTitle: '异常诊断 Agent — 长链推理过程',
    chain: [
      { step: 1, text: '检测到今日 10:30–12:00 GMV 环比下滑 -18.7%，超过阈值 ±10%，触发分层诊断流程' },
      { step: 2, text: '拆分转化漏斗：流量 -8% ≠ GMV -18.7%，差值 10.7pp 来自转化率，排除纯流量问题' },
      { step: 3, text: '定位异常 SKU：「有机米粉 500g」详情页跳失率从基线 42% 升至 65%（+23pp），其余 SKU 正常' },
      { step: 4, text: '交叉客服对话数据：同时段「发货时间」关键词咨询量 +340%，远超日常水平' },
      { step: 5, text: '根因结论：详情页未展示当前活动期发货时效（T+3），用户预期差导致流失，策略移交' },
    ],
  },
  {
    id: 'strategy',
    name: '策略生成 Agent',
    icon: 'Lightbulb',
    color: 'green',
    status: 'running',
    statusLabel: '已生成 4 条',
    summary: '结合历史复盘库，输出促销 / 内容 / 话术 / 投流方案',
    tokenCost: 600000,
    chainTitle: '策略生成 Agent — 推荐逻辑',
    chain: [
      { step: 1, text: '检索策略库 142 条历史记录，语义匹配「详情页跳失+物流预期差」相似场景 Top3' },
      { step: 2, text: '结合今日 GMV 损失量级 ≈¥9,200，按照预期 ROI 对候选策略排序，优先短平快方案' },
      { step: 3, text: '生成 4 条策略：① 补充发货时效说明 ② 限时满减优化 ③ 客服话术更新 ④ 投流出价调整' },
      { step: 4, text: '推送人工确认节点：运营负责人审批后，自动触发实验执行 Agent 创建 A/B 任务' },
    ],
  },
  {
    id: 'experiment',
    name: '实验执行 Agent',
    icon: 'FlaskConical',
    color: 'amber',
    status: 'running',
    statusLabel: '2 组 A/B 进行中',
    summary: '视频封面 A/B · 满减门槛 A/B · 实时监控效果',
    tokenCost: 300000,
    chainTitle: '实验执行 Agent — A/B 实验管理',
    chain: [
      { step: 1, text: '创建实验①：详情页视频封面，50/50 流量分流，北极星指标 = 转化率，最小样本量 1,000' },
      { step: 2, text: '创建实验②：满减门槛 ¥99 vs ¥79，北极星指标 = 客单价 × 转化率，样本量 1,000' },
      { step: 3, text: '实时监控：封面 B组转化率 5.2% vs A组 3.8%，p<0.05 显著；门槛实验尚在置信期' },
      { step: 4, text: '达到样本量后自动判定胜出组，触发全量上线，并推送复盘学习 Agent 归因' },
    ],
  },
  {
    id: 'review',
    name: '复盘学习 Agent',
    icon: 'BrainCircuit',
    color: 'purple',
    status: 'idle',
    statusLabel: '待实验结束',
    summary: '将归因分析结果沉淀至策略库，实现持续自优化',
    tokenCost: 0,
    chainTitle: '复盘学习 Agent — 自优化机制',
    chain: [
      { step: 1, text: '实验结束后提取因果关系模版：「详情页标注发货时效 → 跳失率 -22% → 转化率 +0.8pp」' },
      { step: 2, text: '将有效策略写入策略库，标注置信度 92%，供未来相似场景直接调用' },
      { step: 3, text: '更新异常诊断 Agent 的规则权重：「客服咨询量 +300%」权重提升为 L1 信号' },
      { step: 4, text: '生成周度复盘报告，沉淀为下期活动运营决策依据，策略库当前共 143 条（+1）' },
    ],
  },
]

// ─── 实时异常预警 ─────────────────────────────────────────────────
export const ALERTS = [
  {
    level: 'high',
    title: '详情页跳失异常',
    detail: '有机米粉 SKU 跳失率 65%，较基线 +23pp，预计今日损失 GMV ≈ ¥9,200',
    time: '11:34',
    agent: '异常诊断 Agent',
  },
  {
    level: 'mid',
    title: '退款率持续上升',
    detail: '奶粉品类退款率 4.78%，连续 3 日上升，疑似批次质量问题，已通知仓储核查',
    time: '10:12',
    agent: '异常诊断 Agent',
  },
  {
    level: 'low',
    title: '抖音投流 ROI 下滑',
    detail: '抖音 CPM 上升 18%，ROI 从 3.2 降至 2.7，建议调整出价策略或更换素材',
    time: '09:05',
    agent: '异常诊断 Agent',
  },
]

// ─── 策略推荐 ─────────────────────────────────────────────────────
export const STRATEGIES = [
  {
    id: 'logistics',
    icon: 'Truck',
    name: '补充发货时效说明',
    desc: '在详情页首屏显著位置标注「活动期发货 T+3」，降低预期差',
    lift: '预计转化率 +0.8pp',
    liftColor: 'green',
    priority: 'P0',
  },
  {
    id: 'discount',
    icon: 'Tag',
    name: '限时满减优化',
    desc: '将满减门槛从 ¥99 调整至 ¥79，结合倒计时组件',
    lift: '预计 GMV +¥6,400',
    liftColor: 'green',
    priority: 'P1',
  },
  {
    id: 'service',
    icon: 'MessageSquare',
    name: '客服话术更新',
    desc: '针对「发货时间」咨询自动推送安抚话术 + 满减券引导转化',
    lift: '预计退款率 -0.5pp',
    liftColor: 'green',
    priority: 'P1',
  },
  {
    id: 'ads',
    icon: 'BarChart2',
    name: '投流出价调整',
    desc: '抖音 CPM 过高，建议降低出价上限 15%，切换 oCPX 模式',
    lift: '预计 ROI +0.4',
    liftColor: 'amber',
    priority: 'P2',
  },
]

// ─── A/B 实验 ─────────────────────────────────────────────────────
export const AB_TESTS = [
  {
    id: 'cover',
    name: '详情页视频封面',
    sample: 1240,
    groups: [
      { label: 'A — 原版封面', value: 3.8, color: '#60a5fa' },
      { label: 'B — 新版封面', value: 5.2, color: '#4ade80', winner: true },
    ],
    status: '显著',
    confidence: '97%',
  },
  {
    id: 'discount_threshold',
    name: '满减门槛 ¥99 vs ¥79',
    sample: 980,
    groups: [
      { label: 'A — ¥99 门槛', value: 4.4, color: '#60a5fa' },
      { label: 'B — ¥79 门槛', value: 4.9, color: '#fbbf24' },
    ],
    status: '置信中',
    confidence: '71%',
  },
]

// ─── Token 消耗 ────────────────────────────────────────────────────
export const TOKEN_USAGE = [
  { agent: '数据采集',  used: 840000,  color: '#60a5fa' },
  { agent: '异常诊断',  used: 1260000, color: '#f87171' },
  { agent: '策略生成',  used: 600000,  color: '#4ade80' },
  { agent: '实验执行',  used: 300000,  color: '#fbbf24' },
  { agent: '复盘学习',  used: 0,       color: '#a78bfa' },
]
export const TOKEN_TOTAL = 3000000

// ─── 系统效益指标 ──────────────────────────────────────────────────
export const KPI = [
  { label: '诊断效率提升',    value: '75%',      icon: 'Zap',       color: 'green' },
  { label: '策略迭代周期',    value: '数小时',    icon: 'Clock',     color: 'blue'  },
  { label: '策略库已沉淀',    value: '142 条',    icon: 'BookOpen',  color: 'purple'},
  { label: '本月 A/B 实验',   value: '38 组',     icon: 'FlaskConical', color: 'amber'},
]
