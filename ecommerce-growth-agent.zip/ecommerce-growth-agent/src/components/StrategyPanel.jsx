import React, { useState } from 'react'
import { Truck, Tag, MessageSquare, BarChart2, CheckCircle2, Circle } from 'lucide-react'
import { COLOR_MAP } from '../utils/helpers'
import styles from './StrategyPanel.module.css'

const ICON_MAP = { Truck, Tag, MessageSquare, BarChart2 }
const PRIORITY_COLOR = {
  P0: { bg: 'rgba(248,113,113,0.1)', color: '#f87171' },
  P1: { bg: 'rgba(251,191,36,0.1)',  color: '#fbbf24' },
  P2: { bg: 'rgba(139,144,160,0.08)',color: '#8b90a0' },
}

export default function StrategyPanel({ strategies }) {
  const [approved, setApproved] = useState({})

  return (
    <div className={styles.wrap}>
      <div className={styles.header}>
        <span className={styles.title}>策略推荐</span>
        <span className={styles.sub}>策略生成 Agent · {strategies.length} 条待执行</span>
      </div>
      <div className={styles.grid}>
        {strategies.map(s => {
          const Icon = ICON_MAP[s.icon]
          const lc = COLOR_MAP[s.liftColor]
          const pc = PRIORITY_COLOR[s.priority]
          const isDone = approved[s.id]
          return (
            <div key={s.id} className={`${styles.card} ${isDone ? styles.cardDone : ''}`}>
              <div className={styles.cardTop}>
                <div className={styles.iconWrap} style={{ background: lc.bg }}>
                  <Icon size={16} color={lc.text} />
                </div>
                <span className={styles.priority} style={{ background: pc.bg, color: pc.color }}>
                  {s.priority}
                </span>
              </div>
              <div className={styles.name}>{s.name}</div>
              <div className={styles.desc}>{s.desc}</div>
              <div className={styles.lift} style={{ color: lc.text }}>{s.lift}</div>
              <button
                className={`${styles.approveBtn} ${isDone ? styles.approveDone : ''}`}
                onClick={() => setApproved(prev => ({ ...prev, [s.id]: !prev[s.id] }))}
              >
                {isDone
                  ? <><CheckCircle2 size={12} /> 已批准</>
                  : <><Circle size={12} /> 批准执行</>
                }
              </button>
            </div>
          )
        })}
      </div>
    </div>
  )
}
