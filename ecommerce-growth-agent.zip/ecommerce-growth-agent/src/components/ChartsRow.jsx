import React from 'react'
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  PieChart, Pie, Cell, ResponsiveContainer
} from 'recharts'
import { Zap, Clock, BookOpen, FlaskConical } from 'lucide-react'
import { TOKEN_TOTAL, KPI } from '../data/mockData'
import { fmt, COLOR_MAP } from '../utils/helpers'
import styles from './ChartsRow.module.css'

const KPI_ICON = { Zap, Clock, BookOpen, FlaskConical }

function GmvTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null
  return (
    <div className={styles.tooltip}>
      <div>{label}:00</div>
      <div style={{ color: payload[0].payload.anomaly ? '#f87171' : '#4ade80' }}>
        ¥{payload[0].value.toLocaleString()}
      </div>
    </div>
  )
}

export default function ChartsRow({ gmvData, tokenUsage, trafficSource }) {
  const total = tokenUsage.reduce((s, t) => s + t.used, 0)

  return (
    <div className={styles.row}>
      {/* GMV chart */}
      <div className={styles.card}>
        <div className={styles.cardTitle}>GMV 逐时趋势</div>
        <ResponsiveContainer width="100%" height={110}>
          <AreaChart data={gmvData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="gmvGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%"  stopColor="#4ade80" stopOpacity={0.25} />
                <stop offset="95%" stopColor="#4ade80" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
            <XAxis dataKey="hour" tick={{ fontSize: 9, fill: '#555b6e' }} tickLine={false} axisLine={false} />
            <YAxis tick={{ fontSize: 9, fill: '#555b6e' }} tickLine={false} axisLine={false} tickFormatter={v => `¥${v/1000}k`} />
            <Tooltip content={<GmvTooltip />} />
            <Area
              type="monotone"
              dataKey="value"
              stroke="#4ade80"
              strokeWidth={1.5}
              fill="url(#gmvGrad)"
              dot={(props) => {
                const { cx, cy, payload } = props
                if (!payload.anomaly) return <circle key={`dot-${cx}-${cy}`} r={0} />
                return <circle key={`dot-${cx}-${cy}`} cx={cx} cy={cy} r={4} fill="#f87171" stroke="#0f1117" strokeWidth={2} />
              }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Token usage */}
      <div className={styles.card}>
        <div className={styles.cardTitle}>Token 消耗分布</div>
        <div className={styles.tokenList}>
          {tokenUsage.filter(t => t.used > 0).map((t, i) => (
            <div key={i} className={styles.tokenRow}>
              <span className={styles.tokenLabel}>{t.agent}</span>
              <div className={styles.tokenTrack}>
                <div
                  className={styles.tokenFill}
                  style={{ width: `${Math.round(t.used / TOKEN_TOTAL * 100)}%`, background: t.color }}
                />
              </div>
              <span className={styles.tokenVal}>{fmt(t.used)}</span>
            </div>
          ))}
        </div>
        <div className={styles.tokenTotal}>今日合计 {fmt(total)} Token</div>
      </div>

      {/* Traffic source donut */}
      <div className={styles.card}>
        <div className={styles.cardTitle}>流量来源</div>
        <div className={styles.donutWrap}>
          <ResponsiveContainer width={100} height={100}>
            <PieChart>
              <Pie data={trafficSource} dataKey="value" cx="50%" cy="50%" innerRadius={28} outerRadius={46} strokeWidth={0}>
                {trafficSource.map((entry, index) => (
                  <Cell key={index} fill={entry.color} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div className={styles.legend}>
            {trafficSource.map((s, i) => (
              <div key={i} className={styles.legendItem}>
                <span className={styles.legendDot} style={{ background: s.color }} />
                <span className={styles.legendName}>{s.name}</span>
                <span className={styles.legendVal}>{s.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* KPI */}
      <div className={styles.card}>
        <div className={styles.cardTitle}>系统效益</div>
        <div className={styles.kpiGrid}>
          {KPI.map((k, i) => {
            const Icon = KPI_ICON[k.icon]
            const c = COLOR_MAP[k.color]
            return (
              <div key={i} className={styles.kpiItem} style={{ borderColor: c.border }}>
                <Icon size={13} color={c.text} />
                <div className={styles.kpiValue} style={{ color: c.text }}>{k.value}</div>
                <div className={styles.kpiLabel}>{k.label}</div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
