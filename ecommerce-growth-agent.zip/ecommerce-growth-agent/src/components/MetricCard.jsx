import React from 'react'
import { TrendingDown, TrendingUp } from 'lucide-react'
import styles from './MetricCard.module.css'

export default function MetricCard({ label, value, delta, trend, sub }) {
  return (
    <div className={styles.card}>
      <div className={styles.label}>{label}</div>
      <div className={styles.value}>{value}</div>
      <div className={`${styles.delta} ${styles[trend]}`}>
        {trend === 'down'
          ? <TrendingDown size={12} />
          : <TrendingUp size={12} />}
        {delta}
        <span className={styles.sub}>{sub}</span>
      </div>
    </div>
  )
}
