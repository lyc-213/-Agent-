import React, { useState } from 'react'
import {
  Database, ScanSearch, Lightbulb, FlaskConical, BrainCircuit
} from 'lucide-react'
import { COLOR_MAP } from '../utils/helpers'
import styles from './AgentPanel.module.css'

const ICON_MAP = { Database, ScanSearch, Lightbulb, FlaskConical, BrainCircuit }

const STATUS_STYLE = {
  running: { bg: 'rgba(74,222,128,0.1)',  color: '#4ade80', dot: '#4ade80' },
  alert:   { bg: 'rgba(248,113,113,0.1)', color: '#f87171', dot: '#f87171' },
  idle:    { bg: 'rgba(139,144,160,0.08)',color: '#8b90a0', dot: '#555b6e' },
}

export default function AgentPanel({ agents }) {
  const [activeId, setActiveId] = useState('diagnose')
  const active = agents.find(a => a.id === activeId) || agents[0]
  const c = COLOR_MAP[active.color]

  return (
    <div className={styles.wrap}>
      {/* left: agent list */}
      <div className={styles.list}>
        <div className={styles.sectionTitle}>Agent 协作状态</div>
        {agents.map(agent => {
          const Icon = ICON_MAP[agent.icon]
          const ss = STATUS_STYLE[agent.status]
          const isActive = agent.id === activeId
          const ac = COLOR_MAP[agent.color]
          return (
            <button
              key={agent.id}
              className={`${styles.agentItem} ${isActive ? styles.agentItemActive : ''}`}
              style={isActive ? { borderColor: ac.border, background: ac.bg } : {}}
              onClick={() => setActiveId(agent.id)}
            >
              <div
                className={styles.agentIcon}
                style={{ background: ac.bg, border: `1px solid ${ac.border}` }}
              >
                <Icon size={15} color={ac.text} />
              </div>
              <div className={styles.agentBody}>
                <div className={styles.agentTop}>
                  <span
                    className={styles.agentName}
                    style={isActive ? { color: ac.text } : {}}
                  >
                    {agent.name}
                  </span>
                  <span
                    className={styles.statusBadge}
                    style={{ background: ss.bg, color: ss.color }}
                  >
                    <span
                      className={styles.statusDot}
                      style={{
                        background: ss.dot,
                        boxShadow: agent.status === 'running'
                          ? `0 0 6px ${ss.dot}` : 'none',
                      }}
                    />
                    {agent.statusLabel}
                  </span>
                </div>
                <div className={styles.agentDesc}>{agent.summary}</div>
              </div>
            </button>
          )
        })}
      </div>

      {/* right: chain detail */}
      <div className={styles.chain}>
        <div className={styles.sectionTitle} style={{ color: c.text }}>
          {active.chainTitle}
        </div>
        <div className={styles.chainSteps}>
          {active.chain.map((item, i) => (
            <div key={i} className={styles.chainStep}>
              <div
                className={styles.chainNum}
                style={{ background: c.bg, color: c.text, border: `1px solid ${c.border}` }}
              >
                {item.step}
              </div>
              <div className={styles.chainText}>{item.text}</div>
            </div>
          ))}
        </div>
        {active.tokenCost > 0 && (
          <div className={styles.tokenInfo}>
            <span style={{ color: c.text }}>Token 消耗：</span>
            {(active.tokenCost / 10000).toFixed(0)} 万 / 今日
          </div>
        )}
      </div>
    </div>
  )
}
