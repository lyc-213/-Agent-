import React, { useEffect, useRef } from 'react'
import { Terminal } from 'lucide-react'
import styles from './LiveLog.module.css'

export default function LiveLog({ logs }) {
  const ref = useRef(null)
  useEffect(() => {
    if (ref.current) ref.current.scrollTop = 0
  }, [logs])

  return (
    <div className={styles.wrap}>
      <div className={styles.header}>
        <Terminal size={12} color="#4ade80" />
        <span className={styles.title}>实时系统日志</span>
        <span className={styles.live}>LIVE</span>
      </div>
      <div className={styles.log} ref={ref}>
        {logs.map(l => (
          <div key={l.id} className={styles.line}>
            <span className={styles.time}>{l.time}</span>
            <span className={styles.msg}>{l.msg}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
