import React from 'react'
import styles from './ABTestPanel.module.css'

export default function ABTestPanel({ tests }) {
  return (
    <div className={styles.wrap}>
      <div className={styles.header}>
        <span className={styles.title}>A/B 实验监控</span>
        <span className={styles.sub}>{tests.length} 组进行中</span>
      </div>
      {tests.map(test => (
        <div key={test.id} className={styles.test}>
          <div className={styles.testHeader}>
            <span className={styles.testName}>{test.name}</span>
            <div className={styles.testMeta}>
              <span className={styles.sample}>n={test.sample.toLocaleString()}</span>
              <span
                className={styles.confidence}
                style={{
                  color: test.status === '显著' ? '#4ade80' : '#fbbf24',
                  background: test.status === '显著'
                    ? 'rgba(74,222,128,0.1)' : 'rgba(251,191,36,0.1)',
                }}
              >
                {test.confidence} {test.status}
              </span>
            </div>
          </div>
          {test.groups.map((g, i) => {
            const max = Math.max(...test.groups.map(x => x.value))
            const pct = Math.round((g.value / max) * 100)
            return (
              <div key={i} className={styles.group}>
                <div className={styles.groupLabel}>
                  <span>{g.label}</span>
                  <span
                    className={styles.groupValue}
                    style={{ color: g.winner ? '#4ade80' : 'var(--text-secondary)' }}
                  >
                    {g.value}%{g.winner ? ' ↑' : ''}
                  </span>
                </div>
                <div className={styles.track}>
                  <div
                    className={styles.fill}
                    style={{ width: `${pct}%`, background: g.color }}
                  />
                </div>
              </div>
            )
          })}
        </div>
      ))}
    </div>
  )
}
