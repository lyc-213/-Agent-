import React from 'react'
import { AlertTriangle, AlertCircle, Info, Clock } from 'lucide-react'
import { ALERT_COLOR } from '../utils/helpers'
import styles from './AlertsPanel.module.css'

const ICON_MAP = { high: AlertTriangle, mid: AlertCircle, low: Info }

export default function AlertsPanel({ alerts }) {
  return (
    <div className={styles.wrap}>
      <div className={styles.header}>
        <span className={styles.title}>实时异常预警</span>
        <span className={styles.badge}>{alerts.length}</span>
      </div>
      <div className={styles.list}>
        {alerts.map((alert, i) => {
          const ac = ALERT_COLOR[alert.level]
          const Icon = ICON_MAP[alert.level]
          return (
            <div
              key={i}
              className={styles.item}
              style={{ background: ac.bg, borderColor: ac.border }}
            >
              <div className={styles.itemTop}>
                <div className={styles.itemLeft}>
                  <Icon size={13} color={ac.text} />
                  <span className={styles.level} style={{ color: ac.text }}>
                    {ac.label}
                  </span>
                  <span className={styles.itemTitle}>{alert.title}</span>
                </div>
                <span className={styles.time}>
                  <Clock size={10} />
                  {alert.time}
                </span>
              </div>
              <div className={styles.detail}>{alert.detail}</div>
              <div className={styles.agent}>by {alert.agent}</div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
