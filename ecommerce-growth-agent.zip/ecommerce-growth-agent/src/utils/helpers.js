export function fmt(n) {
  if (n >= 1e6) return (n / 1e6).toFixed(1) + '万'
  if (n >= 1e4) return (n / 1e4).toFixed(0) + '万'
  return n.toLocaleString()
}

export function clx(...classes) {
  return classes.filter(Boolean).join(' ')
}

export const COLOR_MAP = {
  blue:   { text: '#60a5fa', bg: 'rgba(96,165,250,0.1)',  border: 'rgba(96,165,250,0.25)' },
  green:  { text: '#4ade80', bg: 'rgba(74,222,128,0.1)',  border: 'rgba(74,222,128,0.25)' },
  red:    { text: '#f87171', bg: 'rgba(248,113,113,0.1)', border: 'rgba(248,113,113,0.25)' },
  amber:  { text: '#fbbf24', bg: 'rgba(251,191,36,0.1)',  border: 'rgba(251,191,36,0.25)' },
  purple: { text: '#a78bfa', bg: 'rgba(167,139,250,0.1)', border: 'rgba(167,139,250,0.25)' },
  gray:   { text: '#8b90a0', bg: 'rgba(139,144,160,0.08)',border: 'rgba(139,144,160,0.2)'  },
}

export const ALERT_COLOR = {
  high: { text: '#f87171', bg: 'rgba(248,113,113,0.08)', border: 'rgba(248,113,113,0.3)', label: '高风险' },
  mid:  { text: '#fbbf24', bg: 'rgba(251,191,36,0.08)',  border: 'rgba(251,191,36,0.3)',  label: '中风险' },
  low:  { text: '#60a5fa', bg: 'rgba(96,165,250,0.08)',  border: 'rgba(96,165,250,0.3)',  label: '低风险' },
}
