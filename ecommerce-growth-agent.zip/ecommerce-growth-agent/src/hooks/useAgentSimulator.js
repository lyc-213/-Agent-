import { useState, useEffect, useCallback } from 'react'
import { AGENTS, METRICS, ALERTS } from '../data/mockData'

// Simulates real-time agent activity updates
export function useAgentSimulator() {
  const [agents, setAgents] = useState(AGENTS)
  const [metrics, setMetrics] = useState(METRICS)
  const [alerts, setAlerts] = useState(ALERTS)
  const [lastUpdated, setLastUpdated] = useState(new Date())
  const [activeLog, setActiveLog] = useState([])

  const addLog = useCallback((msg) => {
    setActiveLog(prev => [
      { id: Date.now(), time: new Date().toLocaleTimeString('zh-CN', { hour12: false }), msg },
      ...prev.slice(0, 19)
    ])
  }, [])

  // Simulate periodic metric fluctuations
  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics(prev => prev.map(m => {
        if (m.id === 'visitors') {
          const base = 6812
          const noise = Math.floor((Math.random() - 0.5) * 200)
          const newVal = base + noise
          return { ...m, value: newVal.toLocaleString() }
        }
        return m
      }))
      setLastUpdated(new Date())
    }, 8000)
    return () => clearInterval(interval)
  }, [])

  // Simulate agent log stream
  useEffect(() => {
    const logs = [
      '数据采集 Agent：淘宝交易 API 同步完成，新增 1,284 条记录',
      '异常诊断 Agent：检测到「有机米粉 500g」转化率异常，置信度 94%',
      '策略生成 Agent：基于历史策略库匹配到 3 个相似场景',
      '实验执行 Agent：封面 A/B 实验 B组样本量已达 621，继续监控',
      '数据采集 Agent：抖音短视频数据同步，今日播放量 284,720',
      '异常诊断 Agent：退款率 3日趋势分析完成，触发中风险预警',
      '策略生成 Agent：客服话术优化方案已生成，等待人工审批',
      '数据采集 Agent：客服系统 Webhook 接收 342 条对话记录',
      '实验执行 Agent：满减门槛实验样本量达 980，置信度 71%',
      '异常诊断 Agent：抖音 CPM 环比上升 18%，触发低风险预警',
    ]
    let i = 0
    const interval = setInterval(() => {
      addLog(logs[i % logs.length])
      i++
    }, 3500)
    // seed initial logs
    addLog('系统启动，5 个 Agent 初始化完成')
    addLog('数据采集 Agent：开始全量数据同步')
    return () => clearInterval(interval)
  }, [addLog])

  return { agents, metrics, alerts, lastUpdated, activeLog }
}
