import React from 'react'
import { Activity, RefreshCw } from 'lucide-react'
import { useAgentSimulator } from './hooks/useAgentSimulator'
import { GMV_HOURLY, TOKEN_USAGE, TRAFFIC_SOURCE, STRATEGIES, AB_TESTS } from './data/mockData'
import MetricCard from './components/MetricCard'
import AgentPanel from './components/AgentPanel'
import AlertsPanel from './components/AlertsPanel'
import StrategyPanel from './components/StrategyPanel'
import ABTestPanel from './components/ABTestPanel'
import ChartsRow from './components/ChartsRow'
import LiveLog from './components/LiveLog'
import styles from './App.module.css'

export default function App() {
  const { agents, metrics, alerts, lastUpdated, activeLog } = useAgentSimulator()

  return (
    <div className={styles.app}>
      {/* ── Header ── */}
      <header className={styles.header}>
        <div className={styles.brand}>
          <div className={styles.brandIcon}>
            <Activity size={16} color="#4ade80" />
          </div>
          <div>
            <div className={styles.brandName}>增长分析 Agent 系统</div>
            <div className={styles.brandSub}>母婴旗舰店 · 多 Agent 协作运营中枢</div>
          </div>
        </div>
        <div className={styles.headerRight}>
          <div className={styles.livePill}>
            <span className={styles.liveDot} />
            5 Agents 运行中
          </div>
          <div className={styles.updated}>
            <RefreshCw size={10} />
            {lastUpdated.toLocaleTimeString('zh-CN', { hour12: false })} 更新
          </div>
        </div>
      </header>

      <main className={styles.main}>
        {/* ── Metrics row ── */}
        <section className={styles.metrics}>
          {metrics.map(m => <MetricCard key={m.id} {...m} />)}
        </section>

        {/* ── Agent panel (full width) ── */}
        <section className={styles.agentSection}>
          <AgentPanel agents={agents} />
        </section>

        {/* ── Middle row: alerts + strategy + ab ── */}
        <section className={styles.midRow}>
          <AlertsPanel alerts={alerts} />
          <StrategyPanel strategies={STRATEGIES} />
          <ABTestPanel tests={AB_TESTS} />
        </section>

        {/* ── Charts row ── */}
        <section>
          <ChartsRow
            gmvData={GMV_HOURLY}
            tokenUsage={TOKEN_USAGE}
            trafficSource={TRAFFIC_SOURCE}
          />
        </section>

        {/* ── Live log ── */}
        <section>
          <LiveLog logs={activeLog} />
        </section>
      </main>
    </div>
  )
}
