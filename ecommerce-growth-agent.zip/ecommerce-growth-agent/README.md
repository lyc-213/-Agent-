# 🤖 电商增长分析 Agent 系统

> 面向电商运营团队的 AI 多 Agent 协作运营中枢，解决「数据很多但无法形成有效运营决策」的核心痛点。

![预览](https://img.shields.io/badge/React-18-61DAFB?logo=react) ![Vite](https://img.shields.io/badge/Vite-5-646CFF?logo=vite) ![Recharts](https://img.shields.io/badge/Recharts-2-22B5BF)

---

## 核心功能

| 模块 | 描述 |
|------|------|
| **数据采集 Agent** | 实时同步交易 / 流量 / 退款 / 客服 / 短视频 5 路数据 |
| **异常诊断 Agent** | 长链推理定位转化率、退款率、流量异常根因 |
| **策略生成 Agent** | 结合历史策略库生成促销 / 内容 / 话术 / 投流方案 |
| **实验执行 Agent** | 自动创建 A/B 测试并实时监控显著性 |
| **复盘学习 Agent** | 归因分析 → 策略库沉淀 → 持续自优化 |

---

## 快速启动

```bash
# 1. 克隆项目
git clone https://github.com/your-username/ecommerce-growth-agent.git
cd ecommerce-growth-agent

# 2. 安装依赖
npm install

# 3. 本地开发
npm run dev
# → http://localhost:3000

# 4. 构建生产版本
npm run build
```

---

## 部署到 Vercel

```bash
npm i -g vercel
vercel --prod
```

或直接在 [vercel.com](https://vercel.com) 导入此 GitHub 仓库，零配置自动部署。

---

## 项目结构

```
src/
├── components/
│   ├── MetricCard.jsx      # 顶部核心指标卡
│   ├── AgentPanel.jsx      # Agent 协作状态 + 长链推理详情
│   ├── AlertsPanel.jsx     # 实时异常预警（三级风险）
│   ├── StrategyPanel.jsx   # 策略推荐 + 人工审批节点
│   ├── ABTestPanel.jsx     # A/B 实验监控
│   ├── ChartsRow.jsx       # GMV 趋势图 / Token 消耗 / 流量来源 / KPI
│   └── LiveLog.jsx         # 实时系统日志流
├── data/
│   └── mockData.js         # 全部 Mock 数据（替换为真实 API 即可）
├── hooks/
│   └── useAgentSimulator.js # 模拟实时 Agent 状态更新
└── utils/
    └── helpers.js          # 工具函数 + 颜色映射
```

---

## 接入真实数据

`src/data/mockData.js` 中所有 `export const` 均为数据契约，替换为 API 调用即可：

```js
// 示例：替换 GMV 数据为真实接口
// src/data/mockData.js → 改为：
export async function fetchGMVHourly(date) {
  const res = await fetch(`/api/gmv?date=${date}`)
  return res.json()
}
```

---

## 效益指标

| 指标 | 数值 |
|------|------|
| 运营诊断效率提升 | **75%** |
| 策略迭代周期压缩 | 3–5天 → **数小时** |
| 日均 Token 消耗 | **300 万** |
| 策略库沉淀 | **142 条** |

---

## License

MIT
